#include <zmk/event_manager.h>
#include <zmk/events/cycle_animation_state_changed.h>

ZMK_EVENT_IMPL(cycle_animation_state_changed);
